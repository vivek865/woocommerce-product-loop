<!--START Footer-->
<footer>
  <div class="container-fluid fTop">
    <div class="container">
      <div class="col-md-3 col-sm-6 col-xs-12"> <a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/Flogo.png" width="188" height="49" class="flogo" alt=""/></a>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante.</p>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
        <h4>Recent posts</h4>
        <ul class="rpost">
          <li><a href="#">Blog Slideshow Post</a></li>
          <li><a href="#">Aenean Odio Mauris</a></li>
          <li><a href="#">Blog Image Post</a></li>
          <li><a href="#">Blog Video Post</a></li>
          <li><a href="#">Donec Suscpit Dim Euismods</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
        <h4>Recent Tweets</h4>
        <div class="tweets">
          <div class="col-md-12 row"><i class="fa fa-twitter"></i>
            <p>Sed ut perspiciatis, unde omn is iste natus error sit volup tatem accusa ntium dolor emqu.</p>
            <small>12 hours ago</small></div>
          <div class="col-md-12 row"><i class="fa fa-twitter"></i>
            <p>Sed ut perspiciatis, unde omn is iste natus error sit volup tatem accusa ntium dolor emqu.</p>
            <small>12 hours ago</small></div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12">
        <h4>Recent Works</h4>
        <ul class="rworks">
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg01.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg02.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg03.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg03.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg04.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg04.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg01.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg04.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg04.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg03.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg01.jpg" width="59" height="59"  alt=""/></a></li>
          <li><a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/wimg02.jpg" width="59" height="59"  alt=""/></a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- // Footer Top -->
  <div class="container-fluid footer-bottom">
    <div class="container">
      <div class="col-md-6 col-sm-6 col-xs-12">Copyrights 2016 &copy; awesomeone.com. All rights reserved.</div>
      <div class="col-md-6 col-sm-6 col-xs-12">
        <ul>
          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
          <li><a href="#"><i class="fa fa-youtube"></i></a></li>
          <li><a href="#"><i class="fa fa-rss"></i></a></li>
          <li><a href="#"><i class="fa fa-envelope-o"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- // Footer Top --> 
  
</footer>
<!--END Footer--> 
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<?php wp_footer() ; ?>
</body>
</html>