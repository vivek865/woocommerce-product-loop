<?php 

if ( ! function_exists( 'awesome_theme_setup' ) ) :

function awesome_theme_setup() {
	load_theme_textdomain( 'awesome-theme', get_template_directory() . '/languages' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	
	require_once('wp_bootstrap_navwalker.php');
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'awesome-theme' ),
	) );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
	) );
	}
endif;
add_action( 'after_setup_theme', 'awesome_theme_setup' );
function awesome_theme_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'awesome-theme' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'awesome-theme' ),
		'before_widget' => '<div class="sidebar">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'awesome_theme_widgets_init' );
function awesome_theme_scripts() {
	wp_enqueue_script( 'awesome-jquery', get_template_directory_uri() . '/js/jquery-1.11.2.min.js', array(), '', true );
	wp_enqueue_script( 'awesome-bootsrtap',get_template_directory_uri() . '/js/bootstrap.min.js', array(), '',true);
	wp_enqueue_script( 'awesome-pluginsd', get_template_directory_uri() . '/plugins/owl/owl.carousel.min.js', array(), '',true);
	wp_enqueue_script( 'awesome-custom',get_template_directory_uri() . '/js/custom.js', array(), '',true);	wp_enqueue_style( 'awesome-theme-style', get_stylesheet_uri() );
	wp_enqueue_style( 'bootsrtap', get_template_directory_uri() . '/css/bootstrap.min.css',false,'1.1','all' );
	wp_enqueue_style( 'bootsrtap-responsive', get_template_directory_uri() . '/css/responsive.css',false,'1.1','all' );
	wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css',false,'1.1','all' );
    wp_enqueue_style( 'animate', get_template_directory_uri() . '/css/animate.css',false,'1.1','all' );
	wp_enqueue_style( 'set-one', get_template_directory_uri() . '/css/set1.css' ,false,'1.1','all');
	wp_enqueue_style( 'animate-js', get_template_directory_uri() .'/plugins/owl/owl.carousel.css',false,'1.1','all' );
	wp_enqueue_style( 'animate-css', get_template_directory_uri() . '/plugins/owl/owl.theme.css',false,'1.1','all' );
	wp_enqueue_script( 'awesome-html5 ', 'https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js', array(), '1.2' );
	wp_script_add_data( 'awesome-html5', 'conditional', 'lt IE 9' );
	wp_enqueue_script( 'awesome-html5', 'https://oss.maxcdn.com/respond/1.4.2/respond.min.js', array(), '1.3' );
	wp_script_add_data( 'awesome-html5', 'conditional', 'lt IE 9' );
	wp_enqueue_style( 'fonts robot', 'https://fonts.googleapis.com/css?family=Roboto:300,400,500,700',false,'1.1','all' );
	wp_enqueue_style( 'fonts ', 'https://fonts.googleapis.com/css?family=Roboto+Slab',false,'1.2','all' );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'awesome_theme_scripts' );
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';