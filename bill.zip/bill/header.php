<!DOCTYPE html>
<html <?php language_attributes(); ?> >

<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!-- Bootstrap -->
<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>

<?php wp_head();  ?>
</head>
<body <?php body_class(); ?> >
<!--START Header -->
<header>
  <div class="hTop">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="pull-left">Have any Questions?</div>
          <div class="pull-left"><i class="fa fa-skype"></i> +1 100 000 0000</div>
          <div class="pull-left"><i class="fa fa-envelope-o"></i> Mail us - mail@awesomeone.com</div>
        </div>
        <!-- //  col-md-6 col-sm-12 col-xs-12-->
        <div class="col-md-6 col-sm-12 col-xs-12 hidden-xs hidden-sm">
          <ul>
            <li><a href="#" title="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" title="twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" title="google-plus"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#" title="flickr"><i class="fa fa-flickr"></i></a></li>
            <li><a href="#" title="pinterest"><i class="fa fa-pinterest"></i></a></li>
            <li><a href="#" title="instagram"><i class="fa fa-instagram"></i></a></li>
            <li><a href="#" title="behance"><i class="fa fa-behance"></i></a></li>
            <li><a href="#" title="dribbble"><i class="fa fa-dribbble"></i></a></li>
            <li><a href="#" title="youtube"><i class="fa fa-youtube"></i></a></li>
            <li><a href="#" title="vimeo"><i class="fa fa-vimeo"></i></a></li>
            <li><a href="#" title="github"><i class="fa fa-github"></i></a></li>
            <li><a href="#" title="soundcloud"><i class="fa fa-soundcloud"></i></a></li>
            <li><a href="#" title="wordpress"><i class="fa fa-wordpress"></i></a></li>
          </ul>
        </div>
        <!-- //  col-md-6 col-sm-12 col-xs-12--> 
      </div>
      <!-- //  row--> 
    </div>
    <!-- //  container--> 
  </div>
  <!-- //  hTop-->
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-2 col-xs-12 logo"> <a href="#"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo.png" title="awesomeone" class="img-responsive"  alt="awesomeone"/></a> </div>
      <!-- //  logo-->
      <div class="col-md-9 col-sm-10 col-xs-12">
        <nav role="navigation" class="navbar"> 
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <a href="#" class="navbar-brand hidden-sm hidden-md hidden-lg">Menu</a> </div>
          <!-- Collection of nav links, forms, and other content for toggling -->
         <!-- <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="#">Home</a></li>
              <li><a href="#">About</a></li>
              <li><a href="#">Features</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">Our Skills</a></li>
              <li><a href="#">Testimonials</a></li>
              <li><a href="#">Gallery</a></li>
              <li><a href="#">Blog</a></li>
              <li><a href="#">Our Team</a></li>
              <li><a href="#">Contact</a></li>
            </ul>
          </div>-->
		    <?php
            wp_nav_menu( array(
                'menu'              => 'Primary',
                'theme_location'    => 'Primary',
                'depth'             => 2,
                'container'         => 'div',
                'container_class'   => 'collapse navbar-collapse',
              'container_id'      => 'navbarCollapse',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                'walker'            => new wp_bootstrap_navwalker())
            );
        ?>
        </nav>
      </div>
      <!-- //  Menu--> 
    </div>
    <!-- //  row--> 
  </div>
  <!-- //  container--> 
</header>
<!--END Header --> 