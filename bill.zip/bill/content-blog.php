<?php
/**
 * Template part for displaying page content in page.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package staaarter_theme
 */

?>
<div class="row">
            <div class="col-md-4">
              <div class="blog-photo">
                <figure class="effect-kira"> <?php the_post_thumbnail();  ?> 
                  <figcaption>
                    <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/middle1.jpg" title="This is an image title"><i class="fa fa-search effect-3a"></i></a> </p>
                  </figcaption>
                </figure>
                <div class="clearfix"></div>
                <!-- end .clearfix -->
                <div class="blog-info">
                  <p>12<span>MAY</span></p>
                </div>
                <!-- end .blog-info --> 
              </div>
              <!-- end .blog-photo --> 
            </div>
            <!-- end .col-md-4 -->
            
            <div class="col-md-8">
              <div class="blog-title">
                <div class="blog-title-icon"><span><i class="fa fa-file-text"></i></span></div>
                <!-- end .blog-title-icon -->
                <div class="blog-title-body">
                  <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                  <span><i class="fa fa-user"></i><a href="' . esc_url( get_permalink() ) . '"> by Author</a></span> <span><i class="fa fa-comments-o"></i><a href="#' . esc_url( get_permalink() ) . '"> 2 Comments</a></span> <span><i class="fa fa-heart"></i><a href="' . esc_url( get_permalink() ) . '"> 6 Like</a></span> </div>
                <!-- end .blog-title-body --> 
              </div>
              <!-- end .blog-title -->
              <div class="clearfix"></div>
              <!-- end .clearfix -->
              
              <div class="blog-content">
               <?php
			the_content();

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'staaarter-theme' ),
				'after'  => '</div>',
			) );
		?>
              </div>
              <footer class="entry-footer">
		<?php
			edit_post_link(
				sprintf(
					/* translators: %s: Name of current post */
					esc_html__( 'Edit %s', 'staaarter-theme' ),
					the_title( '<span class="screen-reader-text">"', '"</span>', false )
				),
				'<span class="edit-link">',
				'</span>'
			);
		?>
	</footer><!-- .entry-footer -->
              <!-- end .blog-content --> 
            </div>
            <!-- end .col-md-8 --> 
          </div>
           <div class="divider-singledotted"></div>
