<?php get_header() ; ?>
<!--START Section -->
<section> 
  
  <!--  //  map  -->
  <div class="container">
    <div class="col-md-12 text-center blogWrap2">
      <h3>OUR BLOG</h3>
      <span class="icon-title"> <span></span> <i class="fa fa-star"></i></span> </div>
    <div class="row" >
      <div class="col-md-9 col-sm-8">
        <div class="blog-post-middle">
          
        <?php
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) : ?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>

			<?php
			endif;

			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_format() );

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif; ?>
        </div>
      </div>
      <div class="col-md-3 col-sm-4">
        <div class="sidebar">
          <h3>Search</h3>

          <form class="input-group" action="#" method="get">
            <input type="text" class="form-control" name="q" placeholder="Search">
            <span class="input-group-btn">
            <button class="btn btn-default"><i class="fa fa-search"></i></button>
            </span>
          </form>
        </div>
        <!-- //Sideber  -->
        
        <div class="sidebar">
          <h3>Categories</h3>
          <ul class="sidebar-list">
            <li><i class="fa fa-angle-right"></i><a href="#">Architecture Design (50)</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">Project Management (20)</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">3D Design (10)</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">Interior Design (5)</a></li>
          </ul>
        </div>
        <!-- //Sideber  -->
        <div class="sidebar">
          <h3>Recent Posts</h3>
          <div class="sidebar-post clearfix"> <img src="images/post1.jpg" alt="">
            <p>Lorem ipsum dolor sit amet.</p>
            <p><span><a href="#">2016/05/12</a></span></p>
          </div>
          <!-- end .sidebar-post -->
          <div class="sidebar-post clearfix"> <img src="images/post2.jpg" alt="">
            <p>Lorem ipsum dolor sit amet.</p>
            <p><span><a href="#">2016/05/11</a></span></p>
          </div>
          <!-- end .sidebar-post -->
          <div class="sidebar-post clearfix"> <img src="images/post3.jpg" alt="">
            <p>Lorem ipsum dolor sit amet.</p>
            <p><span><a href="#">2016/05/10</a></span></p>
          </div>
          <!-- end .sidebar-post --> 
        </div>
      </div>
    </div>
  </div>
</section>
<!--END MidSection --> 
<?php get_footer() ; ?>